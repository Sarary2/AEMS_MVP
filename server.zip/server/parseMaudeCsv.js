import fs from 'fs';
import csv from 'csv-parser';
import mongoose from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();

const MONGO_URI = process.env.MONGO_URI;

mongoose.connect(MONGO_URI)
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('❌ MongoDB connection error:', err));

const adverseEventSchema = new mongoose.Schema({}, { strict: false });
const AdverseEvent = mongoose.model('AdverseEvent', adverseEventSchema);

const normalizeKey = (key) => key.trim().toLowerCase().replace(/\s+/g, '_');

const results = [];

fs.createReadStream('./maude_data.csv')  // <- ensure this file exists in the same folder
  .pipe(csv({ mapHeaders: ({ header }) => normalizeKey(header) }))
  .on('data', (row) => {
    const cleaned = {
      report_number: row['report_number'],
      event_type: row['event_type'],
      date_received: row['date_received'],
      manufacturer: row['manufacturer'],
      device_name: row['brand_name'],
      description: row['event_text'],
      raw: row // optional: full backup
    };
    results.push(cleaned);
  })
  .on('end', async () => {
    try {
      await AdverseEvent.deleteMany(); // optional: clear old records
      await AdverseEvent.insertMany(results);
      console.log(`✅ Inserted ${results.length} cleaned records into MongoDB`);
      mongoose.disconnect();
    } catch (err) {
      console.error('❌ Insertion error:', err);
      mongoose.disconnect();
    }
  });


