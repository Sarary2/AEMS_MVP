// client/postcss.config.cjs
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};


